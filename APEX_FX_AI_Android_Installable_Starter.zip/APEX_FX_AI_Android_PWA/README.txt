APEX FX AI — ANDROID INSTALLABLE WEB APP (PWA) — BUILD 0.2

CONTENTS
- index.html: dashboard, practice signal journal and cash-risk calculator
- manifest.webmanifest: Android install metadata
- sw.js: offline cache for a hosted copy
- icons/: app icons

IMPORTANT
This is a front-end prototype only. It has no live prices, AI chart reading, MT5 connection, or order execution. It stores practice ideas in the browser on this device. It is not financial advice.

HOW TO INSTALL ON ANDROID (R0)
A Progressive Web App (PWA) normally must be served from HTTPS (or localhost). Opening index.html directly from Downloads may display the dashboard but usually will not offer proper installation/offline features.

Recommended beginner path:
1. Download and unzip this package.
2. From an Android browser, use a free static hosting service that supports HTTPS (for example, GitHub Pages). Creating a repository and uploading the four items/folder may be easier on a computer. Do not publish passwords or account details.
3. Ensure index.html, manifest.webmanifest, sw.js and icons/ are in the published site root.
4. Open the HTTPS site in Chrome on Android.
5. Tap Chrome's ⋮ menu, then "Install app" or "Add to Home screen" (wording varies).
6. Launch APEX FX AI from the new home-screen icon. Reopen it online once so the offline cache can install.

If you only have your phone:
- Extract the ZIP in Files.
- If you have access to GitHub in Chrome, sign in/create a free account, create a public repository such as apex-fx-ai, upload index.html, manifest.webmanifest, sw.js and the icons folder, then enable Settings > Pages to publish from the main branch/root.
- Wait for the Pages URL, open it in Chrome, then use ⋮ > Install app / Add to Home screen.
- GitHub interface may change; don't share your password or recovery codes.

ICONS
The included icon files are simple generated PNG assets.

NEXT TO AUTOMATION
Real MT5 automation requires a broker demo account and MT5 desktop running on a Windows PC or suitable VPS, plus a tested broker-compatible EA. Android MT5 is not a general-purpose environment for running desktop EAs. Keep demo only and use risk caps and an emergency stop.
